# BoAT 白皮书
请访问 [**BoAT白皮书**](https://aitos-io.github.io/BoAT-X-Framework/zh-cn/BoAT_Blockchain_IoT_Module_Product_White_Paper_cn.pdf)
