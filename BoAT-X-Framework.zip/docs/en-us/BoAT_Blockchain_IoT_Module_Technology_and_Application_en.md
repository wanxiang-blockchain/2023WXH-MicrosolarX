# BoAT Blockchain IoT Module Technology and Application
Visit [**BoAT Blockchain IoT Module Technology and Application**](https://aitos-io.github.io/BoAT-X-Framework/en-us/BoAT_Blockchain_IoT_Module_Technology_and_Application_en.pdf)
