# BoAT Whitepaper
Visit [**BoAT Whitepaper**](https://aitos-io.github.io/BoAT-X-Framework/en-us/BoAT_Blockchain_IoT_Module_Product_White_Paper_en.pdf)
