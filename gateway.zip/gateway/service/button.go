package service

import (
	"DGT_Gateway/global"
	"DGT_Gateway/model/system"
	"DGT_Gateway/utils"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/exec"
	"strconv"
)

var lastClickMillis int64 = 0


func ParseButton(body system.ReceiveBody)  {
	args := make(map[string]string)
	for _, v := range body.Args {
		args[v.K] = v.V
	}
	fmt.Println(body)
	// 按键事件上报
	holding, _ := strconv.ParseFloat(args["holding"], 64)
	key := args["keyval"]
	if body.EventId == system.EventId_IOTHub_KEYPRESS {
		switch key{
		case "1":
			FuncKeyPress = true
			if holding >= 5 {

			} else {
				// 开启或者关闭小夜灯
				LightOn = !LightOn
				go ControlLight()
			}
			break
		case "2":
			VoiceKeyPress = true
			if holding >= 5 {
				// TODO 是否需要关闭AP模式，等待与客户确认
				// fmt.Println("AP Model")
			} else {
				bnt := utils.GetTimestamp()
				if global.Config.Volume == -18 {
					global.Config.Volume += 8
				} else if global.Config.Volume == -10 {
					global.Config.Volume += 7
				}else if global.Config.Volume == -3 {
					global.Config.Volume += 6
				} else if global.Config.Volume == 3 {
					global.Config.Volume += 5
				}else if global.Config.Volume == 8 {
					global.Config.Volume += 4
				} else {
					global.Config.Volume = -18
				}
				// global.Config.Volume += 4
				//if global.Config.Volume >= 12 {
				//	global.Config.Volume = -18
				//}
				fmt.Println("current volume = ", global.Config.Volume)
				if bnt - lastClickMillis > 500 {
					go PlayVoice(VoiceType_Voice_Num)
					fmt.Println("Adjust the volume")
				}
				lastClickMillis = bnt

				// 写入配置文件
				data, err := json.Marshal(global.Config)
				if err != nil {
					log.Printf("json.Marshal error:%v", err)
				}
				// 写入文件
				f, err := os.OpenFile(global.AppConfigFile, os.O_WRONLY|os.O_CREATE|os.O_TRUNC|os.O_SYNC, os.ModePerm)
				if err != nil {
					log.Printf("OpenFile %s error:%v", global.AppConfigFile, err)
				}
				defer f.Close()
				_, err = f.Write(data)
				if err != nil {
					log.Printf("WriteFile %s error:%v", global.AppConfigFile, err)
				}
				cmdline := "/bin/sync"
				cmd := exec.Command("sh", "-c", cmdline)
				cmd.Run()
			}
			break
		}
	}
}
