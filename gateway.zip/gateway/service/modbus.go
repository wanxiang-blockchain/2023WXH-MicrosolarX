package service

import (
	"DGT_Gateway/global"
	"DGT_Gateway/model/system"
	"DGT_Gateway/utils"
	"encoding/json"
	"fmt"
	"github.com/simonvetter/modbus"
	"strconv"
	"time"
)

var client  *modbus.ModbusClient
var err      error
var EnergyData  system.EnergyData

func OpenModBus()  {
	// RTU(串行)设备/总线
	client, err = modbus.NewClient(&modbus.ClientConfiguration{
		URL:      "rtu:///dev/ttyS1",
		Speed:    9600,                    // default
		DataBits: 8,                       // default, optional
		Parity:   modbus.PARITY_NONE,      // default, optional
		StopBits: 1,                       // default if no parity, optional
		Timeout:  1000 * time.Millisecond,
	})

	if err != nil {
		fmt.Println(fmt.Sprintf("-------------------- init modbus rtu client err %v -------------------- ", err))
	} else {
		fmt.Println("-------------------- init modbus rtu client successful! -------------------- ")
	}

	err = client.Open()
	if err != nil {
		fmt.Println(fmt.Sprintf("-------------------- open modbus rtu client err %v --------------------", err))
	} else {
		fmt.Println("-------------------- open modbus rtu client successful! -------------------- ")
	}
}

func GetModbusData()  {
	for {
		go getData()
		time.Sleep(10 * time.Second)
	}
}

func getData()  {
	// 从地址100开始读取4个连续的16位输入寄存器
	var reg16s  []uint16
	reg16s, err = client.ReadRegisters(1000, 100, modbus.HOLDING_REGISTER)
	if err != nil {
		fmt.Println(fmt.Sprintf("modbus rtu get model type err %v", err))
	} else {
		fmt.Println("-------------------- modbus rtu data get successful! -------------------- ")
		fmt.Println("-------------------- the rtu data -> -------------------- ")
		fmt.Println(reg16s)
		fmt.Println(fmt.Sprintf("data length -> %v", len(reg16s)))
		fmt.Println("-------------------- end -------------------- ")

		fmt.Println("-------------------- parse data wait sync server -------------------- ")

		moduleType := fmt.Sprintf("%s%s%s%s%s", utils.HexToChar(reg16s[0]), utils.HexToChar(reg16s[1]), utils.HexToChar(reg16s[2]), utils.HexToChar(reg16s[3]), utils.HexToChar(reg16s[4]))

		controlType := reg16s[10]
		moduleFault := reg16s[20]
		moduleStatus := reg16s[22]
		moduleAlert := reg16s[23]
		var p1InputVoltage uint16
		if reg16s[30] > 20000 {
			p1InputVoltage =  0
		} else {
			p1InputVoltage = reg16s[30]
		}

		p1InputElectricity := reg16s[34]
		p1InputPower_H := reg16s[38]
		p1InputPower_L := reg16s[39]
		p1InputPower := (p1InputPower_H << 16) +  p1InputPower_L

		var p2InputVoltage uint16
		if reg16s[31] > 20000 {
			p2InputVoltage =  0
		} else {
			p2InputVoltage = reg16s[31]
		}
		p2InputElectricity := reg16s[35]
		p2InputPower_H := reg16s[40]
		p2InputPower_L := reg16s[41]
		p2InputPower := (p2InputPower_H << 16) + p2InputPower_L

		var p3InputVoltage uint16
		if reg16s[32] > 20000 {
			p3InputVoltage =  0
		} else {
			p3InputVoltage = reg16s[32]
		}
		p3InputElectricity := reg16s[36]
		p3InputPower_H := reg16s[42]
		p3InputPower_L := reg16s[43]
		p3InputPower := (p3InputPower_H << 16) + p3InputPower_L

		var p4InputVoltage uint16
		if reg16s[33] > 20000 {
			p4InputVoltage =  0
		} else {
			p4InputVoltage = reg16s[33]
		}
		p4InputElectricity := reg16s[37]
		p4InputPower_H := reg16s[44]
		p4InputPower_L := reg16s[45]
		p4InputPower := (p4InputPower_H << 16) + p4InputPower_L

		gridVoltageAb := reg16s[46]
		inverterCurrentA := reg16s[47]
		lineFrequency := reg16s[48]
		gridConnectedPowerFactor := reg16s[49]
		gridConnectedActivePower_H := reg16s[50]
		gridConnectedActivePower_L := reg16s[51]
		gridConnectedActivePower := (gridConnectedActivePower_H << 16) + gridConnectedActivePower_L
		gridConnectedReactivePower_H := reg16s[52]
		gridConnectedReactivePower_L := reg16s[53]
		gridConnectedReactivePower := (gridConnectedReactivePower_H << 16) + gridConnectedReactivePower_L
		heatSinkTemperature := reg16s[54]
		dcToEarthVoltage := reg16s[55]
		dcInsulationImpedance := reg16s[56]
		grossGeneration_H := reg16s[57]
		grossGeneration_L := reg16s[58]
		grossGeneration := (grossGeneration_H << 16) + grossGeneration_L
		dailyPowerGeneration_H := reg16s[59]
		dailyPowerGeneration_L := reg16s[60]
		dailyPowerGeneration := (dailyPowerGeneration_H << 16) + dailyPowerGeneration_L

		// 写入数据
		EnergyData.InverterId = fmt.Sprintf("%s%s", "DGTPV000000", strconv.Itoa(int(controlType)))
		EnergyData.ModuleType = moduleType
		EnergyData.ControlType = controlType
		EnergyData.ModuleFault = moduleFault
		EnergyData.ModuleStatus = moduleStatus
		EnergyData.ModuleAlert = moduleAlert

		EnergyData.InverterData.InverterId = fmt.Sprintf("%s%s", "DGTPV000000", strconv.Itoa(int(controlType)))
		EnergyData.InverterData.GridVoltageAb = utils.MathDivRound(gridVoltageAb, 10)
		EnergyData.InverterData.InverterCurrentA = utils.MathDivRound(inverterCurrentA, 10)
		EnergyData.InverterData.LineFrequency = utils.MathDivRound(lineFrequency, 100)
		EnergyData.InverterData.GridConnectedPowerFactor = utils.MathDivRound(gridConnectedPowerFactor, 100)
		EnergyData.InverterData.GridConnectedActivePower = utils.MathDivRound(gridConnectedActivePower, 10)
		EnergyData.InverterData.GridConnectedReactivePower = utils.MathDivRound(gridConnectedReactivePower, 10)
		EnergyData.InverterData.HeatSinkTemperature = utils.MathDivRound(heatSinkTemperature, 10)
		EnergyData.InverterData.DcInsulationImpedance = utils.MathDivRound(dcInsulationImpedance, 1)
		EnergyData.InverterData.DcToEarthVoltage = utils.MathDivRound(dcToEarthVoltage, 10)
		EnergyData.InverterData.DailyPowerGeneration = utils.MathDivRound(dailyPowerGeneration, 10)
		EnergyData.InverterData.GrossGeneration = utils.MathDivRound(grossGeneration, 10)

		// 通道数据
		EnergyData.P1.InputElectricity = utils.MathDivRound(p1InputElectricity, 100)
		EnergyData.P1.InputVoltage = utils.MathDivRound(p1InputVoltage, 100)
		EnergyData.P1.InputPower = utils.MathDivRound(p1InputPower, 100)

		EnergyData.P2.InputElectricity = utils.MathDivRound(p2InputElectricity, 100)
		EnergyData.P2.InputVoltage = utils.MathDivRound(p2InputVoltage, 100)
		EnergyData.P2.InputPower = utils.MathDivRound(p2InputPower, 100)

		EnergyData.P3.InputElectricity = utils.MathDivRound(p3InputElectricity, 100)
		EnergyData.P3.InputVoltage = utils.MathDivRound(p3InputVoltage, 100)
		EnergyData.P3.InputPower = utils.MathDivRound(p3InputPower, 100)

		EnergyData.P4.InputElectricity = utils.MathDivRound(p4InputElectricity, 100)
		EnergyData.P4.InputVoltage = utils.MathDivRound(p4InputVoltage, 100)
		EnergyData.P4.InputPower = utils.MathDivRound(p4InputPower, 100)

		jsonStr, _ := json.Marshal(EnergyData)
		fmt.Println("\n send modbus data is ", string(jsonStr))

		go syncData()
	}
}

func syncData()  {
	url := global.Config.SyncDataUrl
	utils.JSONHTTPPost(url, EnergyData)
}

func mai1n() {

	// 用于TCP端点
	// (参见示例/tls_client。选择TLS使用和选项)
	client, err = modbus.NewClient(&modbus.ClientConfiguration{
		URL:      "tcp://hostname-or-ip-address:502",
		Timeout:  1 * time.Second,
	})
	// note: use udp:// for modbus TCP over UDP

	// RTU(串行)设备/总线
	client, err = modbus.NewClient(&modbus.ClientConfiguration{
		URL:      "rtu:///dev/ttyUSB0",
		Speed:    19200,                   // default
		DataBits: 8,                       // default, optional
		Parity:   modbus.PARITY_NONE,      // default, optional
		StopBits: 2,                       // default if no parity, optional
		Timeout:  300 * time.Millisecond,
	})

	// RTU通过TCP设备/总线(远程串行端口或简单的tcp到串行桥接)
	client, err = modbus.NewClient(&modbus.ClientConfiguration{
		URL:      "rtuovertcp://hostname-or-ip-address:502",
		Speed:    19200,                   // serial link speed
		Timeout:  1 * time.Second,
	})
	//注:使用rtuoverudp:// modbus RTU over UDP

	if err != nil {
		//创建客户端失败
	}

	// 现在客户端已经创建并配置好，尝试连接
	err = client.Open()
	if err != nil {
		//连接/打开设备失败
		//注意:可以在同一个客户端上进行多次Open()尝试，直到
		//连接成功(即err == nil)，再次调用构造函数
		//没有必要。
		//同样地，一个客户端可以根据需要打开和关闭多次。
	}

	// 读取地址为100的16位保持寄存器
	var reg16   uint16
	reg16, err  = client.ReadRegister(100, modbus.HOLDING_REGISTER)
	if err != nil {
		// error out
	} else {
		// use value
		fmt.Printf("value: %v", reg16)        // as unsigned integer
		fmt.Printf("value: %v", int16(reg16)) // as signed integer
	}

	// 从地址100开始读取4个连续的16位输入寄存器
	var reg16s  []uint16
	reg16s, err = client.ReadRegisters(100, 4, modbus.INPUT_REGISTER)
	fmt.Println(reg16s)

	// 读取相同的4个连续16位输入寄存器为2个32位整数
	var reg32s  []uint32
	reg32s, err = client.ReadUint32s(100, 2, modbus.INPUT_REGISTER)
	fmt.Println(reg32s)

	// 读取相同的4个连续16位寄存器作为单个64位整数
	var reg64   uint64
	reg64, err  = client.ReadUint64(100, modbus.INPUT_REGISTER)
	fmt.Println(reg64)

	//读取相同的4个连续16位寄存器作为字节片
	var regBs   []byte
	regBs, err  = client.ReadBytes(100, 8, modbus.INPUT_REGISTER)
	fmt.Println(regBs)

	// 默认情况下，16位整数被解码为大端和32/64位值
	// 大端序，高字在前面。
	// 将后续请求的字节/字序改为小端序
	// 低字优先(注意第二个参数只影响32/64位值)
	client.SetEncoding(modbus.LITTLE_ENDIAN, modbus.LOW_WORD_FIRST)

	// 读取相同的4个连续16位输入寄存器作为2个32位浮点数
	var fl32s   []float32
	fl32s, err  = client.ReadFloat32s(100, 2, modbus.INPUT_REGISTER)
	fmt.Println(fl32s)

	// 写入-200到16位(保持)寄存器100，作为一个有符号整数
	var s int16 = -200
	err         = client.WriteRegister(100, uint16(s))

	// 切换到unit ID(也就是slave ID) #4
	client.SetUnitId(4)

	// 写3浮点寄存器100到105
	err         = client.WriteFloat32s(100, []float32{
		3.14,
		1.1,
		-783.22,
	})

	// 将0x0102030405060708写入16位(保持)寄存器10到13
	// (8字节，即4个连续的modbus寄存器)
	err         = client.WriteBytes(10, []byte{
		0x01, 0x02, 0x03, 0x04,
		0x05, 0x06, 0x07, 0x08,
	})

	// 关闭TCP连接/串口
	client.Close()
}