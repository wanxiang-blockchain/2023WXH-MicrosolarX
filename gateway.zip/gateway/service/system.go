package service

import (
	"DGT_Gateway/global"
	"DGT_Gateway/model/system"
	"DGT_Gateway/utils"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"log"
	"os"
	"os/exec"
	"strings"
	"time"
)

type SystemService struct{}

// OpenStaMode 开启sta模式，网关自身连接wifi上网
func (systemService *SystemService) OpenStaMode(staMode bool)  {
	global.Config.StaMode = staMode
	// 写入配置文件
	data, err := json.Marshal(global.Config)
	if err != nil {
		log.Printf("json.Marshal error:%v", err)
	}
	// 换一种方式写入
	f, err := os.OpenFile(global.AppConfigFile, os.O_WRONLY|os.O_CREATE|os.O_TRUNC|os.O_SYNC, os.ModePerm)
	if err != nil {
		log.Printf("OpenFile %s error:%v", global.AppConfigFile, err)
	}
	defer f.Close()
	_, err = f.Write(data)
	if err != nil {
		log.Printf("WriteFile %s error:%v", global.AppConfigFile, err)
	}

	cmdline := "/bin/sync"
	cmd := exec.Command("sh", "-c", cmdline)
	cmd.Run()
}

// GetStaMode 获取当前网关是否开启了sta模式
func (systemService *SystemService) GetStaMode() bool {
	return global.Config.StaMode
}

// UpdatePassphrase 更新wifi的账号密码并重启
func (systemService *SystemService) UpdatePassphrase(ssid string, psk string) {
	saveWifiConfig(ssid, psk)
	var cmdline string
	if psk == "" {
		// 没有密码的情况 生成配置文件
		cmdline = fmt.Sprintf(`echo "network={%sssid=\"%s\"%skey_mgmt=NONE%s}" > /etc/wpa_supplicant.conf `, "\n",global.Config.SSID, "\n","\n")
	} else {
		// 有密码的情况 生成配置文件
		cmdline = fmt.Sprintf(`echo "network={%sssid=\"%s\"%spsk=\"%s\"%s}" > /etc/wpa_supplicant.conf `, "\n",ssid, "\n",psk,"\n")
	}

	cmd := exec.Command("sh", "-c", cmdline)
	cmd.Run()

	cmdline = "/bin/sync"
	cmd = exec.Command("sh", "-c", cmdline)
	cmd.Run()

	cmd = exec.Command("sh", "-c", "killall wpa_supplicant")
	cmd.Run()

	cmd = exec.Command("sh", "-c", "killall udhcpc")
	cmd.Run()

	// 关闭wifi
	cmd = exec.Command("sh", "-c", "ifconfig wlan1 down")
	cmd.Run()

	// 开启sta模式
	cmdline = "wpa_supplicant -iwlan1 -c /etc/wpa_supplicant.conf -B"
	cmd = exec.Command("sh", "-c", cmdline)
	cmd.Run()

	cmdline = "udhcpc -i wlan1"
	cmd = exec.Command("sh", "-c", cmdline)
	cmd.Start()
}

func (systemService *SystemService) GetScanResultV2() (res system.ScanResult) {
	cmd := exec.Command("sh", "-c", "wpa_cli -i wlan0 scan")
	cmd.Run()
	time.Sleep(3 * time.Second)

	cmd = exec.Command("sh", "-c", "wpa_cli -i wlan0 scan_result | awk '{print $5}'")
	out, _ := cmd.Output()
	value := string(out)

	list := strings.Split(value, "\n")

	for _,v := range list {
		if v != "" {
			// 如果存在16进制数据则转换为中文
			if strings.Contains(v, "\\x") {
				r := strings.ReplaceAll(v,"\\x","")
				b,_ := hex.DecodeString(r)
				v = string(b)
			}
			if utils.ContainsString(res.Ssids, v) == -1{
				res.Ssids = append(res.Ssids, v)
			}
		}
	}
	return res
}

func saveWifiConfig(ssid string, psk string) {
	global.Config.SSID = ssid
	global.Config.PSK = psk
	data, err := json.Marshal(global.Config)
	if err != nil {
		log.Printf("json.Marshal error:%v", err)
	}

	// 换一种方式写入
	f, err := os.OpenFile(global.AppConfigFile, os.O_WRONLY|os.O_CREATE|os.O_TRUNC|os.O_SYNC, os.ModePerm)
	if err != nil {
		log.Printf("OpenFile %s error:%v", global.AppConfigFile, err)
	}
	defer f.Close()
	_, err = f.Write(data)
	if err != nil {
		log.Printf("WriteFile %s error:%v", global.AppConfigFile, err)
	}

	//err = ioutil.WriteFile(global.AppConfigFile, data, 755)
	//if err != nil {
	//	log.Printf("WriteFile %s error:%v", global.AppConfigFile, err)
	//}

	cmdline := "/bin/sync"
	cmd := exec.Command("sh", "-c", cmdline)
	cmd.Run()
}

// Reboot 3s后重启设备
func Reboot() {
	time.Sleep(3 * time.Second)
	cmdline := "/bin/sync"
	cmd := exec.Command("sh", "-c", cmdline)
	cmd.Run()

	cmdline = "reboot"
	cmd = exec.Command("sh", "-c", cmdline)
	cmd.Start()
}

// Reset 恢复出厂设置
func Reset() {
	cmdline := "cp /opt/DGT_SGW/factory/config.json /opt/DGT_SGW/config"
	cmd := exec.Command("sh", "-c", cmdline)
	cmd.Run()

	PlayVoice(VoiceType_Reset_Num)
	Reboot()
}

