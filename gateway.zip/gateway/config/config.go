package config

type Config struct {
	StaMode              bool           `mapstructure:"sta-mode" json:"sta-mode" yaml:"sta-mode"`
	Volume				 int 			`mapstructure:"volume" json:"volume" yaml:"volume"`
	SSID                 string        	`mapstructure:"ssid" json:"ssid" yaml:"ssid"`
	PSK                  string        	`mapstructure:"psk" json:"psk" yaml:"psk"`
	HttpPort             int64         	`mapstructure:"http-port" json:"http-port" yaml:"http-port"`
	GatewayId            string        	`mapstructure:"gateway-id" json:"gateway-id" yaml:"gateway-id"`
	CorsMode             string        	`mapstructure:"cors-mode" json:"cors-mode" yaml:"cors-mode"`
	WhiteList            CORSWhitelist 	`mapstructure:"whitelist" json:"whitelist" yaml:"whitelist"`
	SyncDataUrl			 string 		`mapstructure:"sync-data-url" json:"sync-data-url" yaml:"sync-data-url"`
}

// CORSWhitelist 跨域配置白名单
type CORSWhitelist struct {
	AllowOrigin      string `mapstructure:"allow-origin" json:"allow-origin" yaml:"allow-origin"`
	AllowMethods     string `mapstructure:"allow-methods" json:"allow-methods" yaml:"allow-methods"`
	AllowHeaders     string `mapstructure:"allow-headers" json:"allow-headers" yaml:"allow-headers"`
	ExposeHeaders    string `mapstructure:"expose-headers" json:"expose-headers" yaml:"expose-headers"`
	AllowCredentials bool   `mapstructure:"allow-credentials" json:"allow-credentials" yaml:"allow-credentials"`
}

type Contact struct {
	Type 	uint32 	`mapstructure:"type" json:"type" yaml:"type"`
	Num 	string 	`mapstructure:"num" json:"num" yaml:"num"`
}

type SubDevice struct {
	DeviceId 		string 	`mapstructure:"deviceId" json:"deviceId" yaml:"deviceId"`
	DeviceType 		string 	`mapstructure:"deviceType" json:"deviceType" yaml:"deviceType"`
	DeviceStatus 	string 	`mapstructure:"deviceStatus" json:"deviceStatus" yaml:"deviceStatus"`
	LastOnlineTime 	string 	`mapstructure:"lastOnlineTime" json:"lastOnlineTime" yaml:"lastOnlineTime"`
}