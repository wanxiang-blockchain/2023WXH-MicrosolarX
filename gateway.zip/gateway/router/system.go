package router

import (
	system2 "DGT_Gateway/api/v1/system"
	"github.com/gin-gonic/gin"
)

type SystemRouter struct{}

func (system *SystemRouter) InitSystemRouter(Router *gin.RouterGroup) (R gin.IRoutes) {
	systemRouter := Router.Group("")
	systemApi := new(system2.SystemApi)
	{
		systemRouter.POST("getServerInfo", systemApi.GetServerInfo)   		// test 获取服务器参数信息
		systemRouter.POST("voiceControl", systemApi.VoiceControl)     		// test 语音提示控制
		systemRouter.POST("dbusSendDataToIOTHub", systemApi.DbusSendDataToIOTHub)
		systemRouter.POST("getModbusData", systemApi.GetModbusData)

		systemRouter.POST("funcKey", systemApi.FuncKey)
		systemRouter.POST("voiceKey", systemApi.VoiceKey)
		systemRouter.POST("sosKey", systemApi.SOSKey)
		systemRouter.POST("speaker", systemApi.Speaker)
		systemRouter.POST("mic", systemApi.Mic)
		systemRouter.POST("zigbee", systemApi.Zigbee)
		systemRouter.POST("cat4", systemApi.Cat4)
		systemRouter.POST("wifiScan", systemApi.WifiScan)
		systemRouter.POST("lightRGB", systemApi.LightRGB)
		systemRouter.POST("getSSID",systemApi.GetSSID)
		systemRouter.POST("getSignLevel",systemApi.GetSignLevel)
		systemRouter.POST("getOperator",systemApi.GetOperator)
		systemRouter.POST("getIMSI",systemApi.GetIMSI)

		systemRouter.POST("reset", systemApi.Reset)                         	// 恢复出厂设置
		systemRouter.POST("reboot", systemApi.Reboot)                       	// 重启设备
		systemRouter.POST("ap_scan", systemApi.GetScanResult)               	// 获取周边AP列表
		systemRouter.POST("apply_sta_model", systemApi.OpenStaMode)			// 配置sta模式
		systemRouter.POST("query_sta_model_status", systemApi.GetStaMode)	// 获取当前是否是sta模式
		systemRouter.POST("apply_wifi", systemApi.WifiReconfigure)          	// 配置wifi
	}
	return systemRouter
}
