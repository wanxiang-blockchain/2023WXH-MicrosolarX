package system

import (
	"DGT_Gateway/global"
	response "DGT_Gateway/model/common/reponse"
	"DGT_Gateway/model/common/request"
	"DGT_Gateway/model/system"
	"DGT_Gateway/service"
	"github.com/gin-gonic/gin"
)

var productService = new(service.ProductService)
var systemService = new(service.SystemService)

type SystemApi struct{}

/********************************* 调试接口 *********************************/

func (s *SystemApi) GetServerInfo(c *gin.Context) {
	system := global.Config
	response.OkWithDetailed(gin.H{"server": system, "version": global.Version, "versionNum": global.VersionNum}, "获取成功", c)
}

func (s *SystemApi) VoiceControl(c *gin.Context) {
	var params request.GetById
	_ = c.ShouldBindJSON(&params)
	if params.ID >= 0 && params.ID <= 16 {
		service.PlayVoice(int(params.ID))
		response.Ok(c)
	} else {
		response.FailWithMessage("integer value is not valid", c)
	}
}

func (s *SystemApi) DbusSendDataToIOTHub(c *gin.Context) {
	var params system.ReceiveBody
	_ = c.ShouldBindJSON(&params)
	service.SendDataToIOTHub(params)
	response.Ok(c)
}

func (s *SystemApi) GetModbusData(c *gin.Context) {
	data := service.EnergyData
	response.OkWithDetailed(gin.H{"modbusData": data}, "获取成功", c)
}

/********************************* 产测接口 *********************************/

func (s *SystemApi) FuncKey (c *gin.Context) {
	res := productService.FuncKey()
	response.OkWithData(res, c)
}

func (s *SystemApi) VoiceKey (c *gin.Context) {
	res := productService.VoiceKey()
	response.OkWithData(res, c)
}

func (s *SystemApi) SOSKey (c *gin.Context) {
	res := productService.SOSKey()
	response.OkWithData(res, c)
}

func (s *SystemApi) Speaker (c *gin.Context) {
	productService.Speaker()
	response.Ok(c)
}

func (s *SystemApi) Mic (c *gin.Context) {
	productService.Mic()
	response.Ok(c)
}

func (s *SystemApi) Zigbee (c *gin.Context) {
	res := productService.Zigbee()
	response.OkWithData(res, c)
}

func (s *SystemApi) Cat4 (c *gin.Context) {
	res := productService.Cat4()
	response.OkWithData(res, c)
}

func (s *SystemApi) WifiScan (c *gin.Context) {
	res := productService.WifiScan()
	response.OkWithData(res, c)
}

func (s *SystemApi) LightRGB (c *gin.Context) {
	var json system.LightLED
	if err := c.ShouldBindJSON(&json); err != nil {
		response.FailWithDetailed(gin.H{"status": "Invalid Parameters"}, "", c)
		return
	}
	productService.LightRGB(json.LED)
	response.Ok(c)
}

func (s *SystemApi) GetSSID (c *gin.Context) {
	res := productService.GetSSID()
	response.OkWithData(res, c)
}

func (s *SystemApi) GetSignLevel (c *gin.Context) {
	res := productService.GetSignLevel()
	response.OkWithData(res, c)
}

func (s *SystemApi) GetOperator (c *gin.Context) {
	res := productService.GetOperator()
	response.OkWithData(res, c)
}

func (s *SystemApi) GetIMSI (c *gin.Context) {
	res := productService.GetIMSI()
	response.OkWithData(res, c)
}

/********************************* 正式接口 *********************************/

// GetScanResult 获取当前ap并返回列表
func (s *SystemApi) GetScanResult(c *gin.Context) {
	res := systemService.GetScanResultV2()
	response.OkWithDetailed(res, "获取成功", c)
}

// GetStaMode 获取当前是否开启sta模式
func (s *SystemApi) GetStaMode(c *gin.Context) {
	status := systemService.GetStaMode()
	response.OkWithDetailed(gin.H{"status": status}, "获取成功", c)
}

// OpenStaMode 开启/关闭sta模式
func (s *SystemApi) OpenStaMode(c *gin.Context) {
	var json system.StaModeStatus
	if err := c.ShouldBindJSON(&json); err != nil {
		response.FailWithDetailed(gin.H{"status": "Invalid Parameters"}, "", c)
		return
	}
	systemService.OpenStaMode(json.StaMode)
	response.Ok(c)
}

// WifiReconfigure 配置wifi
func (s *SystemApi) WifiReconfigure(c *gin.Context) {
	var json system.WifiConfig
	if err := c.ShouldBindJSON(&json); err != nil {
		response.FailWithDetailed(gin.H{"status": "Invalid Parameters"}, "", c)
		return
	}
	go systemService.UpdatePassphrase(json.Ssid, json.Password)
	response.Ok(c)
}

// Reset 恢复出厂设置
func (s *SystemApi) Reset(c *gin.Context) {
	go service.Reset()
	response.OkWithMessage("正在恢复出厂设置...", c)
}

// Reboot 重启设备
func (s *SystemApi) Reboot(c *gin.Context) {
	go service.Reboot()
	response.OkWithMessage("设备将在3s后执行重启...", c)
}

