package initialize

import (
	"DGT_Gateway/config"
	"DGT_Gateway/global"
	"DGT_Gateway/utils"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"os/exec"
	"time"
)

var Config config.Config

func ReadConfig() error {
	log.Printf("Loading configure file (%s)...", global.AppConfigFile)
	data, err := ioutil.ReadFile(global.AppConfigFile)
	if err != nil {
		log.Printf("ReadFile %s error:%v", global.AppConfigFile, err)
		return err
	}

	log.Printf("Configure Loaded: \r\n%s", string(data))

	err = json.Unmarshal(data, &Config)
	if err != nil {
		log.Printf("json.Unmarshal error:%v", err)
		return err
	}

	// 读取设备IMEI号 修改IMEI相关内容
	IMEI := utils.GetIMEI()
	if IMEI != "nameError" {
		Config.GatewayId = IMEI
	} else {
		log.Printf("Can't Get device IMEI Err:%v", IMEI)
	}
	global.Config = Config
	log.Printf("Get config json data:%v", Config)

	// 初始化服务器地址
	global.Config.SyncDataUrl = "http://222.244.147.83:8089/api/device/report/data"

	// 初始化wifi 生成配置文件
	var cmdline string
	if global.Config.PSK != "" {
		cmdline = fmt.Sprintf(`echo "network={%sssid=\"%s\"%spsk=\"%s\"%s}" > /etc/wpa_supplicant.conf `, "\n",global.Config.SSID, "\n",global.Config.PSK,"\n")
	} else {
		cmdline = fmt.Sprintf(`echo "network={%sssid=\"%s\"%skey_mgmt=NONE%s}" > /etc/wpa_supplicant.conf `, "\n",global.Config.SSID, "\n","\n")
	}
	cmd := exec.Command("sh", "-c", cmdline)
	cmd.Run()

	cmdline = "/bin/sync"
	cmd = exec.Command("sh", "-c", cmdline)
	cmd.Run()

	time.Sleep(1 * time.Second)

	// 写入设备IMEI号到配置文件
	SaveConfig()
	return nil
}

func SaveConfig() error {
	var data []byte
	var err error
	data, err = json.Marshal(global.Config)
	if err != nil {
		log.Printf("json.Marshal error:%v", err)
		return err
	}
	// 换一种方式写入
	f, err := os.OpenFile(global.AppConfigFile, os.O_WRONLY|os.O_CREATE|os.O_TRUNC|os.O_SYNC, os.ModePerm)
	if err != nil {
		log.Printf("OpenFile %s error:%v", global.AppConfigFile, err)
		return err
	}
	defer f.Close()
	_, err = f.Write(data)
	if err != nil {
		log.Printf("WriteFile %s error:%v", global.AppConfigFile, err)
		return err
	}
	return nil
}
