package initialize

import (
	"DGT_Gateway/global"
	"DGT_Gateway/model/system"
	"DGT_Gateway/service"
	"DGT_Gateway/utils"
	"fmt"
	"os/exec"
	"time"
)

func ConnectNetV2() {
	fmt.Println("Start checking if wifi & 4G is available")
	if global.Config.StaMode {
		if !service.NetWork {
			closeWlan1v2()
			fmt.Println("Wifi cannot connect to the Internet, turn on sta mode")
			// 开启sta模式
			cmdline := "wpa_supplicant -iwlan1 -c /etc/wpa_supplicant.conf -B"
			cmd := exec.Command("sh", "-c", cmdline)
			cmd.Run()

			cmdline = "udhcpc -i wlan1"
			cmd = exec.Command("sh", "-c", cmdline)
			cmd.Start()

			time.Sleep(10 * time.Second)

			cmdline = fmt.Sprintf("ping www.baidu.com -c 4 -W 1")
			cmd = exec.Command("sh", "-c", cmdline)
			err := cmd.Run()
			if err == nil {
				service.NetWork = true
			}

			time.Sleep(2 * time.Second)
		}

		if !service.NetWork {
			closeWlan1v2()
			fmt.Println("4G is down. Start dialing")
			isConnectionCat4v2(true)

			time.Sleep(10 * time.Second)

			cmdline := fmt.Sprintf("ping www.baidu.com -c 4 -W 1")
			cmd := exec.Command("sh", "-c", cmdline)
			err := cmd.Run()
			if err == nil {
				service.NetWork = true
			}

			time.Sleep(2 * time.Second)

			if !service.NetWork {
				isConnectionCat4v2(false)
				fmt.Println("The STA mode is enabled, but the network cannot be connected. start 4G dial,but 4G is down")
			} else {
				fmt.Println("choose 4G surf the internet")
				// 网络已连接，关闭提示灯光
				service.Cat4Status = true
				service.NetWork = true
				go service.ControlLight()
				go service.PlayVoice(service.VoiceType_Network_OK_Num)
				fmt.Println("The wifi connection is abnormal. The 4G connection is normal and the wifi has been disconnected")

				// ntpd时间校准
				cmd := exec.Command("sh", "-c", "ntpd -p ntp.aliyun.com")
				cmd.Run()
			}
		} else {
			// 网络已连接，关闭提示灯光
			fmt.Println("choose WIFI surf the internet")
			service.NetWork = true
			go service.ControlLight()
			go service.PlayVoice(service.VoiceType_Network_OK_Num)
			// wifi正常断开4G
			isConnectionCat4v2(false)
			fmt.Println("The wifi is normal and 4G is disconnected")

			// ntpd时间校准
			cmd := exec.Command("sh", "-c", "ntpd -p ntp.aliyun.com")
			cmd.Run()

			time.Sleep(10 * time.Second)
		}
	} else {
		// sta mode 已关闭 使用4G网络桥接自身AP上网
		if !service.NetWork {
			// 处理4G连接逻辑
			fmt.Println("4G is down. Start dialing")
			isConnectionCat4v2(true)

			time.Sleep(10 * time.Second)

			cmdline := fmt.Sprintf("ping www.baidu.com -c 4 -W 1")
			cmd := exec.Command("sh", "-c", cmdline)
			err := cmd.Run()
			if err == nil {
				service.NetWork = true
			}

			time.Sleep(2 * time.Second)

			if !service.NetWork {
				isConnectionCat4v2(false)
				fmt.Println("The STA mode is disabled, start 4G dial,but the network cannot be connected, 4G is down")
			} else {
				fmt.Println("sta mode is disabled, choose 4G surf the internet")
				closeWlan1v2()
				// 网络已连接，关闭提示灯光
				service.Cat4Status = true
				service.NetWork = true
				go service.ControlLight()
				go service.PlayVoice(service.VoiceType_Network_OK_Num)
				fmt.Println("The 4G connection is abnormal. The 4G connection is normal and the wifi has been disconnected")

				// ntpd时间校准
				cmd := exec.Command("sh", "-c", "ntpd -p ntp.aliyun.com")
				cmd.Run()

				time.Sleep(10 * time.Second)
			}
		}
	}
}

// CheckNetV2 网络检查15s一次 如果不通开始重新连接4G
func CheckNetV2() {
	for true {
		fmt.Println("Start check network")
		if !service.NetWork {
			fmt.Println("Network connection...")
			// 语音提示用户
			go service.PlayVoice(service.VoiceType_Network_Error_Num)
			// 联网指示灯开启
			service.NetWork = false
			// 网络连接异常 黄灯快闪
			go service.ControlLight()
			ConnectNetV2()
		} else {
			fmt.Println("network OK")
		}
		time.Sleep(60 * time.Second)
	}
}

func isConnectionCat4v2(flag bool) {
	var sendBody system.ReceiveBody
	sendBody.UUID = utils.GetUUID()
	sendBody.EventType = system.EventType_Event
	sendBody.Nonce = utils.GetNonce()
	sendBody.Source = system.EventSource_Monitor
	if flag {
		sendBody.EventId = system.EventId_IOTHub_DIAL_IFUP
	} else {
		sendBody.EventId = system.EventId_IOTHub_DIAL_IFDOWN
	}
	// 写入事件表
	go service.SendDataToIOTHub(sendBody)
}

func closeWlan1v2()  {
	cmd := exec.Command("sh", "-c", "killall wpa_supplicant")
	cmd.Run()

	cmd = exec.Command("sh", "-c", "killall udhcpc")
	cmd.Run()

	// 关闭wifi
	cmd = exec.Command("sh", "-c", "ifconfig wlan1 down")
	cmd.Run()
}
