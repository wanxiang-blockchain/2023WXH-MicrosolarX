package initialize

import (
	"DGT_Gateway/router"
	common "DGT_Gateway/utils"
	"github.com/gin-gonic/gin"
)

func Routers() *gin.Engine {
	Router := gin.Default()

	// 直接放行全部跨域请求
	Router.Use(common.Cors())
	// 按照配置的规则放行跨域请求
	// Router.Use(common.CorsByRules())

	systemRouter := new(router.SystemRouter)
	PublicGroup := Router.Group("")
	{
		// 注册基础功能路由 不做鉴权
		systemRouter.InitSystemRouter(PublicGroup)
	}
	return Router
}
