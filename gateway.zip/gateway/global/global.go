package global

import (
	"DGT_Gateway/config"
	"sync"
)

var (
	Version        	= "v1.1.2-t"								// 当前软件版本
	VersionNum		= 112										// 当前软件版本标识
	AppConfigFile 	= "/opt/DGT_SGW/config/config.json"			// sgw应用配置文件
	Config        	config.Config   							// 全局配置文件
	WaitGroup     	*sync.WaitGroup 							// 协程管理器
)
