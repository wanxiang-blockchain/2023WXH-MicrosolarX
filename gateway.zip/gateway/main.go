package main

import (
	"DGT_Gateway/global"
	"DGT_Gateway/initialize"
	"DGT_Gateway/service"
	"fmt"
	"github.com/gin-gonic/gin"
	"net/http"
	"sync"
	"time"
)

/*
 * 1.下载protobuf编译器 https://github.com/protocolbuffers/protobuf/releases/tag/v3.19.4
 * 2.将下载的protobuf解压，bin目录添加到环境变量，cmd输入protoc --version
 * 3.安装go protocol buffers的插件 protoc-gen-go，go install google.golang.org/protobuf/cmd/protoc-gen-go@latest
 * 4.protoc-gen-go这个插件会自动下载到你的go path的bin目录下。
 * 5.根据proto生成go文件：protoc --plugin=protoc-gen-go=D:\DGT\GolangApp\go\bin\protoc-gen-go.exe --go_out . iot.proto
 * 6.D:\DGT\GolangApp\go\bin\protoc-gen-go.exe 该目录为protoc-gen-go可执行程序路径，注意设置proto文件中的包名：option go_package
 */

func main() {
	// 初始化读取配置文件
	initialize.ReadConfig()

	// 注册DBUS
	service.RegisterDbusInterface()

	// 全局协程管理器
	var wg sync.WaitGroup
	global.WaitGroup = &wg

	// connection net
	go initialize.CheckNetV2()

	// 打开modbus 串口
	service.OpenModBus()

	// 读取modbus数据
	go service.GetModbusData()
	// 启动服务器
	RunServer()
}

type server interface {
	ListenAndServe() error
}

func RunServer() {
	Router := initialize.Routers()
	address := fmt.Sprintf(":%d", global.Config.HttpPort)
	s := initServer(address, Router)
	// 保证文本顺序输出
	// In order to ensure that the text order output can be deleted
	time.Sleep(10 * time.Microsecond)
	fmt.Println("server address=====", address)
	fmt.Println(s.ListenAndServe().Error())
}

func initServer(address string, router *gin.Engine) server {
	return &http.Server{
		Addr:           address,
		Handler:        router,
		ReadTimeout:    20 * time.Second,
		WriteTimeout:   20 * time.Second,
		MaxHeaderBytes: 1 << 20,
	}
}
