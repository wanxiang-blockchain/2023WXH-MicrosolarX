package system

type EnergyData struct {
	// 逆变器编号
	InverterId  	string 					`json:"inverterId"`
	// 模块型号
	ModuleType 		string 					`json:"moduleType"`
	// 控制板型号
	ControlType 	uint16 					`json:"controlType"`
	// 模块故障量
	ModuleFault 	uint16 					`json:"moduleFault"`
	// 模块状态量
	ModuleStatus 	uint16 					`json:"moduleStatus"`
	// 模块告警量
	ModuleAlert 	uint16 					`json:"moduleAlert"`
	// 逆变器数据
	InverterData 	InverterData 			`json:"inverterData"`
	// 逆变器通道数据
	P1 				InverterChannelData 	`json:"p1"`
	P2 				InverterChannelData 	`json:"p2"`
	P3 				InverterChannelData 	`json:"p3"`
	P4 				InverterChannelData 	`json:"p4"`
}

// InverterChannelData 逆变器通道数据
type InverterChannelData struct {
	// 输入电压
	InputVoltage 		float32 	`json:"inputVoltage"`
	// 输入电流
	InputElectricity 	float32 	`json:"inputElectricity"`
	// 输入功率
	InputPower 			float32 	`json:"inputPower"`
}

// InverterData 逆变器数据
type InverterData struct {
	// 逆变器编号
	InverterId 					string 		`json:"inverterId"`
	// 电网电压
	GridVoltageAb  				float32 	`json:"gridVoltageAb"`
	// 电网电流
	InverterCurrentA 			float32 	`json:"inverterCurrentA"`
	// 电网频率
	LineFrequency 				float32 	`json:"lineFrequency"`
	// 并网功率因数
	GridConnectedPowerFactor 	float32 	`json:"gridConnectedPowerFactor"`
	// 并网有功功率
	GridConnectedActivePower 	float32 	`json:"gridConnectedActivePower"`
	// 并网无功功率
	GridConnectedReactivePower 	float32 	`json:"gridConnectedReactivePower"`
	// 散热器温度
	HeatSinkTemperature 		float32  	`json:"heatSinkTemperature"`
	// 直流绝缘阻抗
	DcInsulationImpedance 		float32  	`json:"dcInsulationImpedance"`
	// 直流对地电压
	DcToEarthVoltage 			float32  	`json:"dcToEarthVoltage"`
	// 每天发电量
	DailyPowerGeneration 		float32  	`json:"dailyPowerGeneration"`
	// 总发电量
	GrossGeneration 			float32  	`json:"grossGeneration"`
}
