package system

type EventId string

const (
	EventId_MediaCenter_Start_Push_Stream EventId = "StartRtsp"    			// 开始推流事件
	EventId_MediaCenter_Stop_Push_Stream  EventId = "StopRtsp"     			// 结束推流事件
	EventId_MediaCenter_Start_Recording   EventId = "StartMp4"     			// 结束录制事件
	EventId_MediaCenter_Stop_Recording    EventId = "StopMp4"      			// 结束录制事件
	EventId_CallService_Register_Server   EventId = "REGISTER"     			// 音视频通话注册服务器事件
	EventId_IOTHub_Open_Network           EventId = "OPEN_NETWORK" 			// IOT zigbee开始组网
	EventId_IOTHub_CLOSE_NETWORK		  EventId = "CLOSE_NETWORK" 		// IOT zigbee关停组网
	EventId_IOTHub_FORCE_LEAVE            EventId = "FORCE_LEAVE"  			// IOT zigbee子设备退网
	EventId_IOTHub_Manage				  EventId = "MANAGE"  	   			// IOT zigbee子设备管理事件
	EventId_IOTHub_State				  EventId = "STATE"  	   			// IOT zigbee子设备数据上报事件
	EventId_IOTHub_RAW				      EventId = "RAW"  	   	   			// IOT zigbee子设备睡眠检测带特殊数据上报事件
	EventId_IOTHub_LIGHT_ON			      EventId = "LIGHT_ON"   			// IOT 控制灯光
	EventId_IOTHub_LIGHT_OFF			  EventId = "LIGHT_OFF"   			// IOT 控制灯光
	EventId_IOTHub_KEYPRESS				  EventId = "KEYPRESS"	   			// IOT 上报按键事件
	EventId_IOTHub_PHONE				  EventId = "PHONE"	   				// IOT 上报call事件
	EventId_IOTHub_PHONE_TERM			  EventId = "PHONE_TERM"			// 拒接或挂断
	EventId_IOTHub_PHONE_ANS			  EventId = "PHONE_ANS"				// 接听
	EventId_IOTHub_PHONE_CALL			  EventId = "PHONE_CALL"			// 拨号，带参数number
	EventId_IOTHub_DIAL_IFUP			  EventId = "DIAL_IFUP"				// 4G 拨号
	EventId_IOTHub_DIAL_CON			  	  EventId = "DAIL_CON"				// 4G 连接成功
	EventId_IOTHub_DIAL_IFDOWN			  EventId = "DIAL_IFDOWN"			// 断开4G连接
	EventId_IOTHub_DAIL_CONNECTED		  EventId = "DAIL_CONNECTED"		// 拨号成功事件
	EventId_IOTHub_PHONE_RESET			  EventId = "PHONE_RESET"			// 重启linphone
	EventId_IOTHub_QUERY_ACTIVE_CALL	  EventId = "QUERY_ACTIVE_CALL"		// 查询是否有通话正在进行
	EventId_IOTHub_CHECK_ZB_STATUS		  EventId = "CHECK_ZB_STATUS"		// 查询zigbee状态
	EventId_IOTHub_QUERY_REGISTER_STATE	  EventId = "QUERY_REGISTER_STATE"	// 查询sip注册状态
	EventId_IOTHub_VOICE				  EventId = "VOICE"	   				// IOT 上报sim call事件
	EventId_IOTHub_VOICE_CALL			  EventId = "VOICE_CALL"			// sim通话主叫
	EventId_IOTHub_VOICE_TERM			  EventId = "VOICE_TERM"			// sim通话挂断
	EventId_IOTHub_VOICE_ANS			  EventId = "VOICE_ANS"				// sim通话接听
)

type EventSource string

const (
	EventSource_MediaCenter EventSource = "MediaCenter" // 流媒体服务事件发起者标识
	EventSource_CallService EventSource = "CallService" // 音视频通话事件发起者标识
	EventSource_IOTHub      EventSource = "IOTHub"      // zigbee子设备事件发起者标识
	EventSource_Monitor     EventSource = "Monitor"     // golang自身事件发起标识
)

type EventType string

const (
	EventType_Reply EventType = "REPLY" // 回复
	EventType_CMD 	EventType = "CMD"	// cmd需要回复，发送结构
	EventType_Event EventType = "EVENT"	// event不需要回复，发送结构
)

const (
	//DeviceType_SLEEP_MON_NO string = "9003"
	//DeviceType_INFRARED_NO string = "1205"
	//DeviceType_GAS_NO string = "1206"
	//DeviceType_MAGNET_NO string = "1204"

	DeviceType_SLEEP_MON_MODEL 	string = "RH9004"			// 睡眠检测带
	DeviceType_INFRARED_MODEL 	string = "MIR-IR100-E"		// 红外传感器
	DeviceType_GAS_MODEL 		string = "MIR-GA100-E"		// 燃气传感器
	DeviceType_MAGNET_MODEL 	string = "MIR-MC100-E"		// 门磁传感器
	DeviceType_SMOKE_MODEL 		string = "MIR-SM100-E"		// 烟雾传感器
	DeviceType_FLOOD_MODEL 		string = "MIR-WA100-E"		// 水浸传感器
	DeviceType_SOS_MODEL 		string = "MIR-SO100-E"
)

const (
	CallState_CALL 					string = "CALL"						// 自用类型 去电
	CallState_INCOMING 				string = "INCOMING"					// 来电
	CallState_END 					string = "END"						// 结束通话
	CallState_CONNECTED				string = "CONNECTED"				// 接通
	CallState_OUTGOING_ESTABLISHING string = "OUTGOING_ESTABLISHING"	// 建立连接中
	CallState_OUTGOING_PROGRESS		string = "OUTGOING_PROGRESS"		// 接通之前的状态
	CallState_OUTGOING_RINGING		string = "OUTGOING_RINGING"			// 响铃中 暂时无用
	CallState_ERROR					string = "ERROR"					// ERROR
	CallType_SIP					string = "SIP"						// 通话类型sip
	CallType_VOLTE					string = "VOLTE"					// sim卡通话
)

type ReceiveBody struct {
	Nonce     string      `json:"nonce"`
	UUID      string      `json:"uuid"`
	Source    EventSource `json:"source"`
	SubDevice string      `json:"sub-device"`
	EventType EventType   `json:"event-type"`
	EventId   EventId     `json:"event-id"`
	Args      []Args      `json:"args"`
}

type ReplyBody struct {
	Nonce     string    `json:"nonce"`
	UUID      string    `json:"uuid"`
	EventType EventType `json:"event-type"`
	EventId   EventId   `json:"event-id"`
	Status    bool      `json:"status"`
	Args      []Args    `json:"args"`
}

type Args struct {
	K string `json:"k"`
	V string `json:"v"`
}