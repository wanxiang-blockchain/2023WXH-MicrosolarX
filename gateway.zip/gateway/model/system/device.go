package system

type DiskStatus struct {
	All  uint64 `json:"all"`
	Used uint64 `json:"used"`
	Free uint64 `json:"free"`
}

type ScanResult struct {
	Ssids []string `json:"ssid"`
}

type WifiConfig struct {
	Ssid     string `json:"ssid"`
	Password string `json:"psk"`
}

// RecordConfig 录制参数配置
type RecordConfig struct {
	Status   bool   `json:"status"`
	Duration string `json:"duration"`
}

type Device struct {
	DeviceSN string `json:"device-sn"`
}

type PlayBackRecord struct {
	StartTime string `json:"startTime"`
	EndTime   string `json:"endTime"`
	FileName  string `json:"fileName"`
	PushUrl   string `json:"pushUrl"`
}

type LightControl struct {
	Model         string `json:"model"`
	LightState    string `json:"lightState"`
}

type Payload struct {
	Alarm string `json:"alarm"`
}

type StaModeStatus struct {
	StaMode bool `json:"sta-mode"`
}

type LightLED struct {
	LED string `json:"led"`
}