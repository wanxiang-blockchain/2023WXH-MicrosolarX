package request

// PageInfo Paging common input parameter structure
type PageInfo struct {
	Page     int `json:"page" form:"page"`         // 页码
	PageSize int `json:"pageSize" form:"pageSize"` // 每页大小
}

// GetById Find by id structure
type GetById struct {
	ID float64 `json:"id" form:"id"` // 主键ID
}

type GetByProtoData struct {
	Data string `json:"data" form:"data"` // protoData
}

func (r *GetById) Uint() uint {
	return uint(r.ID)
}

func (d *GetByProtoData) GetData() string {
	return d.Data
}

type IdsReq struct {
	Ids []int `json:"ids" form:"ids"`
}

type Empty struct{}
