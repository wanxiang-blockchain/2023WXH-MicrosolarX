package utils

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"
	"time"
	"unsafe"
)

func JSONHTTPPost(url string, data interface{}) (string, error) {
	bytesData, err := json.Marshal(data)
	if err != nil {
		return "", err
	}

	reader := bytes.NewReader(bytesData)
	request, err := http.NewRequest("POST", url, reader)
	if err != nil {
		return "", err
	}

	request.Header.Set("Content-Type", "application/json;charset=UTF-8")
	client := http.Client{Timeout: 3 * time.Second}
	resp, err := client.Do(request)
	if err != nil {
		return "", err
	}

	respBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	str := (*string)(unsafe.Pointer(&respBytes))
	return *str, nil
}
