package utils

import (
	"DGT_Gateway/model/system"
	"bytes"
	"fmt"
	"github.com/golang/protobuf/jsonpb"
	"github.com/golang/protobuf/proto"
	"github.com/syndtr/goleveldb/leveldb/errors"
	"math/rand"
	"os"
	"os/exec"
	"sort"
	"strconv"
	"strings"
	"time"
)

func BytesToHexString(b []byte) string {
	var buf bytes.Buffer
	for _, v := range b {
		t := strconv.FormatInt(int64(v), 16)
		if len(t) > 1 {
			buf.WriteString(t)
		} else {
			buf.WriteString("0" + t)
		}
	}
	return buf.String()
}

// HexStringToBytes hex string to bytes
func HexStringToBytes(s string) []byte {
	bs := make([]byte, 0)
	for i := 0; i < len(s); i = i + 2 {
		b, _ := strconv.ParseInt(s[i:i+2], 16, 16)
		bs = append(bs, byte(b))
	}
	return bs
}

// TransProtoToJson hex string to bytes
func TransProtoToJson(pb proto.Message) string {
	var pbMarshaller jsonpb.Marshaler
	pbMarshaller = jsonpb.Marshaler{
		EmitDefaults: true,
		OrigName:     true,
		EnumsAsInts:  true,
	}
	_buffer := new(bytes.Buffer)
	_ = pbMarshaller.Marshal(_buffer, pb)
	return string(_buffer.Bytes())
}

// GetIMEI linux 下获取设备
func GetIMEI() string {
	cmd := exec.Command("sh", "-c", "/bin/cat /tmp/imei")
	out, _ := cmd.Output()
	idPart := string(out)
	if idPart != "" {
		imei := strings.Trim(idPart, "\t\r\n")
		imei = strings.TrimSpace(idPart)
		return imei
	}
	return "nameError"
}

// GetCpuTemperature linux 下获取CPU温度
func GetCpuTemperature() string {
	cmd := exec.Command("sh", "-c", " cat /sys/class/thermal/thermal_zone0/temp")
	out, err := cmd.Output()

	if err != nil {
		fmt.Println(err)
		return string("ERR")
	}
	var ID1 string = ""
	ID1 = string(out)
	return ID1
}

// GetRuntime linux 下获取设备已运行时间
func GetRuntime() string {
	cmd := exec.Command("sh", "-c", "awk -F. '{print $1}' /proc/uptime")
	out, err := cmd.Output()

	if err != nil {
		fmt.Println(err)
		return string("ERR")
	}

	var ID1 string = ""
	ID1 = string(out)
	return ID1
}

// DiskUsage 内存卡可用空间
func DiskUsage(path string) (disk system.DiskStatus) {
	//fs := syscall.Statfs_t{}
	//err := syscall.Statfs(path, &fs)
	//if err != nil {
	//	return
	//}
	//disk.All = fs.Blocks * uint64(fs.Bsize)
	//disk.Free = fs.Bfree * uint64(fs.Bsize)
	//disk.Used = disk.All - disk.Free
	return disk
}

// ByModTime 路径下文件排序方法
type ByModTime []os.FileInfo

func (fis ByModTime) Len() int {
	return len(fis)
}

func (fis ByModTime) Swap(i, j int) {
	fis[i], fis[j] = fis[j], fis[i]
}

func (fis ByModTime) Less(i, j int) bool {
	return fis[i].ModTime().Before(fis[j].ModTime())
}

// SortFile 根目录下的文件按时间大小排序，从远到近
func SortFile(path, name string) (files ByModTime) {
	f, err := os.Open(path)
	if err != nil {
		fmt.Println(err)
	}
	fis, err := f.Readdir(-1)
	if err != nil {
		fmt.Println(err)
	}
	defer f.Close()
	files = make(ByModTime, len(fis)+10)
	j := 0
	for i, v := range fis {
		if strings.Contains(fis[i].Name(), name) {
			files[j] = v
			j++
		}
	}
	files = files[:j]
	sort.Sort(ByModTime(files))
	return
}

func PathExists(path string) bool {
	_, err := os.Stat(path)
	if err == nil {
		return true
	}
	if os.IsNotExist(err) {
		return false
	}
	return false
}

// RmFile 格式化内存卡 之前需要停掉所有应用
func RmFile() {
	cmd := exec.Command("sh", "-c", "rm -rf /mnt/sdcard/*")
	cmd.Run()
	cmd = exec.Command("sh", "-c", "sync")
	cmd.Run()
}

// In 字符串数组是否包含字符串
func In(target string, strArray []string) bool {
	for _, element := range strArray {
		if target == element {
			return true
		}
	}
	return false
}

// Contains 字符串数组是否包含字符串内容
func Contains(target string, strArray []string) bool {
	for _, element := range strArray {
		if strings.Contains(element, target) {
			return true
		}
	}
	return false
}

// DelItem string数组移除指定元素
func DelItem(vs []string, s string) []string {
	maxIdx := len(vs) - 1
	for i := maxIdx; i >= 0; i-- {
		if s == vs[i] {
			vs = append(vs[:i], vs[i+1:]...)
		}
	}
	return vs
}

func randomStr(n int) string {
	var l = []rune("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
	rand.Seed(time.Now().UnixNano())
	b := make([]rune, n)
	length := len(l)
	for i := range b {
		b[i] = l[rand.Intn(length)]
	}
	return string(b)
}

func Random2(strings []string) string {  //字符串数组
	for i := len(strings) - 1; i > 0; i-- {
		num := rand.Intn(i + 1)
		strings[i], strings[num] = strings[num], strings[i]
	}
	str := ""
	for i := 0; i < len(strings); i++ {
		str += strings[i]
	}
	return str
}

func GetUUID() string {
	timestamp := time.Now().UnixNano() / 1e6
	s := randomStr(19)
	str := strings.Split(fmt.Sprintf("%s%s",  strconv.FormatInt(timestamp, 10),s),"")
	return Random2(str)
}

func GetNonce() string {
	timestamp := time.Now().UnixNano() / 1e6
	return strconv.FormatInt(timestamp, 10)
}

func GetTimestamp() int64  {
	timestamp := time.Now().UnixNano() / 1e6
	return timestamp
}

func ContainsString(array []string, val string) (index int) {
	index = -1
	for i := 0; i < len(array); i++ {
		if array[i] == val {
			index = i
			return
		}
	}
	return
}

func RunCmd(cmdStr string) (error, string){
	list := strings.Split(cmdStr, " ")
	cmd := exec.Command(list[0],list[1:]...)
	var out bytes.Buffer
	var stderr bytes.Buffer
	cmd.Stdout = &out
	cmd.Stderr = &stderr
	err := cmd.Run()
	if err != nil {
		return errors.New(stderr.String()), "fail"
	} else {
		return nil, out.String()
	}
}

func MathDivRound(num1 uint16, num2 uint16) float32 {
	f := float32(num1) / float32(num2)
	return f
}

func HexToCharV2(uNum uint16) string {
	n1 := uNum / 256
	n2 := uNum % 256
	return fmt.Sprintf("%s%s",fmt.Sprintf("%c", n1), fmt.Sprintf("%c", n2))
}

func HexToChar(uNum uint16) string  {
	// 将拿到的10进制数据转换为16进制
	hex := strconv.FormatInt(int64(uNum), 16)
	// 将16进制数据前2个字节转换为10进制
	n1, _ := strconv.ParseUint(hex[:2], 16, 32)
	n2, _ := strconv.ParseUint(hex[2:4], 16, 32)
	// 对应输出对应Ascii字符
	return fmt.Sprintf("%s%s",fmt.Sprintf("%c", n1), fmt.Sprintf("%c", n2))
}